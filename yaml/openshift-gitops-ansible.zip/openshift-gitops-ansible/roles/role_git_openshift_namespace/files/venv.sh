#!/usr/bin/env bash
# creates a python virtual environment to run Ansible.
python3 -m venv namespace-onboarding
source namespace-onboarding/bin/activate
pip install --upgrade pip
python3 -m pip install -r requirements.txt
ansible --version
