#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright: (c) 2023, salanisor <[email protected]>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

from __future__ import print_function
__metaclass__ = type

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['preview'],
                    'supported_by': 'community'}

DOCUMENTATION = r'''
---
module: git_branch
short_description: Creates a feature branch from current local git directory.
description:
    - Module simply creates a feature branch from the existing local git directory.
version_added: "2.9"
options:
  path:
    description:
      - Path to local git repository.
    required: yes
    type: path
  branch:
    description:
      - Name of feature branch.
    required: yes
    type: str
author:
    - @salanisor
'''

RETURN = '''
msg:
    description: Returns branch information
    returned: always
    type: str
    ok: [127.0.0.1] => {
    "changed": false,
    "images": [
        "registry.redhat.io/openshift-service-mesh/sidecar-injector-rhel8@sha256:3d5715fb1e9facb9a7a06869cb6d7992708825959982e1782b30d71f917001b4"
    ],
    "invocation": {
        "module_args": {
            "dest": "/tmp/ansible.zgm3dutocontent",
            "operator_name": "servicemeshoperator",
            "src": "/tmp/ansible.7s73ltrxmanifest"
        }
    }
}

'''

EXAMPLES = '''
- name: "Create feature branch from INCxxx"
  git_branch:
    branch: "{{snow_incident}}"
    path: "{{temp_dir.path}}/{{git_local_dir}}"

'''
import git
import os
import shutil
from pathlib import Path
from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils._text import to_bytes, to_native, to_text

def main():

    git_status = str()

    module = AnsibleModule(
        argument_spec=dict(
            branch=dict(type='str', required=True),
            path=dict(type='path', required=True)
        )
    )

    params = module.params
    feature_branch = params['branch']
    git_repo_path = params['path']

    checkout_branch(feature_branch,git_repo_path)
    push_branch(feature_branch,git_repo_path)
    module.exit_json(changed=False, meta=git_status)

def checkout_branch(feature_branch,git_repo_path):
    if feature_branch == None or git_repo_path == None:
        raise ValueError("Please assign right Branches and Path")
    else:
        if os.path.isdir(git_repo_path):
            repo = git.Repo(git_repo_path)
            git_ = repo.git
            git_.checkout('-b', feature_branch)
            git_.add(".")
            git_.commit("-am", "adding namespace objects via INC..")

def push_branch(feature_branch,git_repo_path):
    if feature_branch == None or git_repo_path == None:
        raise ValueError("Please assign right Branches and Path")
    else:
        if os.path.isdir(git_repo_path):
            ssh_cmd = 'ssh -i /tmp/git_key'
            repo = git.Repo(git_repo_path)
            with repo.git.custom_environment(GIT_SSH_COMMAND=ssh_cmd):
                git_ = repo.git
                git_.push("--set-upstream", "origin", feature_branch)
                git_status = git_.status()

if __name__ == '__main__':
    main()